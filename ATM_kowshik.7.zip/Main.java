import java.util.Scanner;
public class Main
{
    public static void main(String args[] ) {
        Account x = new Account();
        x.option();
        Scanner sc = new Scanner(System.in);
        int cho = sc.nextInt();

            if (cho == 1 || cho == 2) {
                while (true) {

                System.out.println("Entry the Card or Account Number:");
                int card = sc.nextInt();
                System.out.println("Enter the Password: ");
                int pass = sc.nextInt();
                int withdraw, deposit;

                Account a1 = new Account();
                a1.setAcn(1234);
                a1.setPin(111);
                int a = a1.getPin();
                int b = a1.getAcn();
                a1.setBalance(100000);
                int balance = a1.getBalance();
                 a1.setAcn(4321);
                 a1.setPin(222);
                 int c = a1.getAcn();
                 int d = a1.getPin();
                if ((card == b && pass == a)  || (card==c && pass==d )) {
                    Account a2 = new Account();
                    a2.Manu();
                    System.out.print("Choose the operation:");

                    int choice = sc.nextInt();
                    switch (choice) {
                        case 1: {
                            System.out.print("Enter money to be withdrawn:");

                            withdraw = sc.nextInt();

                            if (balance >= withdraw) {
                                balance = balance - withdraw;
                                System.out.println("Please collect your money!");
                            } else {
                                System.out.println("Insufficient Balance");
                            }

                            break;
                        }

                        case 2: {

                            System.out.print("Enter money to be deposited:");
                            deposit = sc.nextInt();

                            balance = balance + deposit;
                            System.out.print("Your Money has been successfully depsited By" + deposit + "Take\n");
                            System.out.println("");
                            break;
                        }
                        case 3: {

                            System.out.println("Balance : " + balance);
                            System.out.println("");
                            break;
                        }
                        case 4: {
                            System.exit(0);
                        }
                    }
                }
                else {
                    Atm f1 = new Atm();
                    f1.Manu();
                }

            }

        }

        }
    }

