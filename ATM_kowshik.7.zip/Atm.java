public class Atm {
   private int balance;
    private int acn;

    private int pin;


    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {

        this.balance = balance;
    }



    public int getAcn() {

        return acn;
    }

    public void setAcn(int acn) {

        this.acn = acn;
    }

    public int getPin() {

        return pin;
    }

    public void setPin(int pin) {

        this.pin = pin;
    }
    void Manu()
    {
        System.out.println("Worng Password & Account Number!plz try Again");
    }
}
