public class Account extends Atm {
   @Override
    void Manu()
    {
        System.out.println("1.Withdraw");
        System.out.println("2.Deposit");
        System.out.println("3.Cheak Balance");
        System.out.println("4.EXIT");

    }
    void option()
    {
        System.out.println("1.Rocket");
        System.out.println("2.Card");
    }

}
